import random

codigo_tamanho = 16
caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'

quantidade_codigos = int(input("[ made by c0ffee ] Quantos códigos você deseja gerar? "))

for i in range(quantidade_codigos):
    codigo = ''
    for j in range(codigo_tamanho):
        codigo += random.choice(caracteres)
    print(f"Código {i+1}: discord.gift/{codigo}")
    
# Criado por Café S2#9738

input("\nPressione Enter para sair...")

